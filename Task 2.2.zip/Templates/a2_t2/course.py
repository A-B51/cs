# -*- coding: utf-8 -*-
"""
a2_t2.course
17-622-887
<Andre Bittencourt>
"""
from .student import Student


class Course:
    # The Course class. A course should have a name, a code, a number of credits, and a student limit.

    def __init__(self, name, code, credit, student_limit):
        self.name = name
        self.code = code
        self.credit = credit
        self.student_limit = student_limit
        # creating empty list for students
        self.students = []

    def __str__(self):
        course = self.name + ', ' + str(self.code) + ', ' + str(self.credit) + ', ' + str(self.student_limit) + ', ' + self.students
        return course

    def add_student(self, student):
        # A method to add a given student to the list of students of the course. Before adding a student to the list,
        # check if the maximum number of students has already been reached. Raise a CourseCapacityFullError if this is the case.
        
#        print(len(self.students), ' ',  self.student_limit)

        if len(self.students) >= self.student_limit:
            print('CourseCapacityFullError')

        # VERY IMPORTANT TO PUT str() FUNCTION! otherwiese it throwa just the saving place
        else: 
            self.students += [str(student)]
#        print(self.students)
#        print(self.students[0])
        return self.students



    def remove_student_by_number(self, student_number):
        # A method to remove a student from the list of students given only his/her student number. Iterate over all students
        # in the list and check if the student number of each student corresponds to the number given as input value for the
        # method. Raise a StudentNotEnrolledError if the student cannot be found in the list.
        self.student_number = student_number

        for i in range(len(self.students)):
            
            # Selecting list element to convert it into an integer (specified in Student class)
            number = self.students[i]

            # Selecting the number based on the specified __str__ in the student class. Remeber: *element_included : *element excluded
            number = int(number[number.index('<') + 1 : number.index('>')])
            #print(number)

            if self.student_number == number:

             #   print(self.students.index(self.students[i]))

                # Selecting the right index of the list to cancel element
                delete = self.students.index(self.students[i])

                # cancelling element
                self.students.pop(delete)

               #  self.students -= self.students[i]
                return self.students

            else: print('Student not found')
    

    def to_string(self):
        # A method to create a nicely formatted string representation of a course including its name, code, maximum number
        # of students as well as the details for each enrolled student. Refer to the example output given on the assignment
        # sheet, which should be created when executing the client_2.py file.
        string = ""

        # getting number of students
        enrolled_students = len(self.students)
        
        # printing list of all students 
        # print(*self.students, sep='\n')

        print(f"==Course information== \n Name: {self.name} \n Code: {self.code} \n Maximum Students: {self.student_limit} \n Number of Students enrolled: {enrolled_students} \n Enrolled students:")
        print(*self.students, sep='\n')
        return string

class CourseCapacityFullError(Exception):
    """Raised when adding a student to the course and it is already full"""


class StudentNotEnrolledError(Exception):
    """Raised when removing a student from the course and the student is not enrolled"""
