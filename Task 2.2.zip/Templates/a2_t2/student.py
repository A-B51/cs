# -*- coding: utf-8 -*-
"""
a2_t2.student
17-622-887
<Andre Bittencourt>
"""

class Student:
    # The Student class. A sutdent should have a name and a number as attributes.

    def __init__(self, name, number):
        self.name = name
        self.number = number

    def __str__(self):
        student = self.name + ' ' + '<' + str(self.number) + '>'
        return student
