# -*- coding: utf-8 -*-
"""
a2_t2.department
17-622-887
<Andre Bittencourt>
"""
from .course import Course

class Department:
    # The Department class. A Department should have a name, a code, and a list of courses.

    def __init__(self, name, code):
        self.name = name
        self.code = code
        # creating an empty list for this class
        self.courses = []

    def add_course(self, course):
        # A method to add a given course to the list of courses of the department. DONT FORGET THE SELF, otherwise the computer just deals with it as it was a local var
        self.courses += [course]
        return self.courses
