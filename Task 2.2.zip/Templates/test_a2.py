# -*- coding: utf-8 -*-
""" Test script for Assignment 2 Tasks 1 and 2. Do not change! """

import names
import pytest
import a2_t2

from card_game import generate_deck
from card_game import store_score
from card_game import shuffle
from card_game import deal_cards
from card_game import play_round
from card_game import play_game

# test Task 1
def test_task1_generate_deck():
    deck = generate_deck([])
    assert deck[0] == ['2 of Clubs','Clubs','2']
    assert deck[1] == ['3 of Clubs', 'Clubs', '3'], "the deck was not generated correctly"
    assert deck[14] == ['3 of Diamonds', 'Diamonds', '3'], "the deck was not generated correctly"

def test_task1_store_score():
    deck = generate_deck([])
    score_dict = store_score(deck)
    assert score_dict['3 of Clubs']==4, "the card score was not calculated correctly"
    assert score_dict['7 of Hearts'] == 10, "the card score was not calculated correctly"
    assert score_dict['Ace of Spades'] == 18, "the card score was not calculated correctly"

def test_task1_shuffle_deck():
    deck = generate_deck([])
    shuffled_deck = deck.copy()
    shuffled_deck = shuffle(shuffled_deck)
    shuffled_deck2 = deck.copy()
    shuffled_deck2 = shuffle(shuffled_deck2)
    assert shuffled_deck != shuffled_deck2, "the deck may have not been shuffled correctly"

def test_task1_deal_cards():
    deck = generate_deck([])
    shuffled_deck = deck.copy()
    shuffled_deck = shuffle(shuffled_deck)
    deck_player1, deck_player2 = deal_cards(shuffled_deck)
    assert (len(deck_player1)==5&len(deck_player2)==5), "the cards are not distributed correctly"
    assert deck_player1[0] == shuffled_deck[0], "the cards are not distributed correctly"
    assert deck_player2[0] == shuffled_deck[1], "the cards are not distributed correctly"
    assert deck_player1[4] == shuffled_deck[8], "the cards are not distributed correctly"
    assert deck_player2[4] == shuffled_deck[9], "the cards are not distributed correctly"

def test_task1_play_round():
    deck = generate_deck([])
    score_dict = store_score(deck)
    card1 = ['2 of Clubs','Clubs','2']
    card2 = ['3 of Clubs', 'Clubs', '3']
    assert play_round(card1,card2,score_dict)==2, "a round is not implemented correctly"
    card3 = ['10 of Spades', 'Spades', '10']
    card4 = ['4 of Hearts', 'Hearts', '4']
    assert play_round(card3, card4, score_dict) == 1, "a round is not implemented correctly"
    card5 = ['Jack of Hearts', 'Hearts', 'Jack']
    assert play_round(card3, card5, score_dict) == 0, "a round is not implemented correctly"

def test_task1_play_game():
    deck = generate_deck([])
    score_dict = store_score(deck)
    deck2_player1=[['Queen of Diamonds', 'Diamonds', 'Queen'], ['3 of Diamonds', 'Diamonds', '3'], ['5 of Clubs', 'Clubs', '5'], ['7 of Diamonds', 'Diamonds', '7'], ['Jack of Diamonds', 'Diamonds', 'Jack']]
    deck2_player2=[['Jack of Clubs', 'Clubs', 'Jack'], ['King of Diamonds', 'Diamonds', 'King'], ['10 of Hearts', 'Hearts', '10'], ['7 of Clubs', 'Clubs', '7'], ['6 of Hearts', 'Hearts', '6']]
    assert play_game(deck2_player1, deck2_player2,score_dict)==1, "a game is not implemented correctly"

# test Student class
test_students = [
    ("Alice", 1336),
]
@pytest.mark.parametrize("name,number", test_students)
def test_task2_1(name, number):
    """ Test Task 2.1 """
    std = a2_t2.Student(name, number)
    assert std.name == name
    assert std.number == number

# test Department class
test_departments = [
    ("Mathematics and Applied Mathematics", "MAM"),
]
@pytest.mark.parametrize("name,code", test_departments)
def test_task2_2(name, code):
    """ Test Task 2.2 """
    dpt = a2_t2.Department(name, code)
    assert dpt.name == name
    assert dpt.code == code
    assert dpt.courses == []
    crs0 = a2_t2.Course("course name 0", "course code 0 ", 2, 1)
    dpt.add_course(crs0)
    assert len(dpt.courses) == 1, "a course wasn't added to the department"
    assert isinstance(dpt.courses[0], a2_t2.Course)
    assert dpt.courses[0].name == crs0.name and dpt.courses[0].code == crs0.code
    crs1 = a2_t2.Course("course name 1", "course code 0 ", 2, 1)
    dpt.add_course(crs1)
    assert len(dpt.courses) == 2, "the department was unable to hold multiple courses"
    assert dpt.courses[1] == crs1

# test Course class
test_courses = [
    ("Mathematics 1000", "MAM1000W", 1, 10),
]
@pytest.mark.parametrize("name,code,credit,student_limit", test_courses)
def test_task1_3(name, code, credit, student_limit):
    """ Test Task 2.3 """
    crs = a2_t2.Course(name, code, credit, student_limit)
    assert crs.name == name
    assert crs.code == code
    assert crs.credit == credit
    assert crs.student_limit == student_limit
    assert crs.students == []
    std0 = a2_t2.Student("alice", 0)
    std1 = a2_t2.Student("bob", 1)
    std2 = a2_t2.Student("charlie", -1)
    crs.add_student(std0)
    assert len(crs.students) == 1, "a student wasn't added to the course"
    crs.add_student(std1)
    assert len(crs.students) == 2, "the course was unable to hold multiple students"
    for i in range(2, student_limit):
        crs.add_student(a2_t2.Student(names.get_full_name(), i))
    with pytest.raises(a2_t2.CourseCapacityFullError):
        crs.add_student(std2)
    assert len(crs.students) == student_limit, "add_student not implemented properly"
    with pytest.raises(a2_t2.StudentNotEnrolledError):
        crs.remove_student_by_number(std2.number)
    assert len(crs.students) == student_limit, "remove_student_by_number not implemented properly"
    crs.remove_student_by_number(std0.number)
    assert len(crs.students) == student_limit-1
    # test __str__

